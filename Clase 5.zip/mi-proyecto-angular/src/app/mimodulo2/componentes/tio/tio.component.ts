import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tio',
  templateUrl: './tio.component.html',
  styleUrls: ['./tio.component.css']
})
export class TioComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
