import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tia',
  templateUrl: './tia.component.html',
  styleUrls: ['./tia.component.css']
})
export class TiaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
