// Para crear un componente nuevo ejecutamos en la consola `ng (g)enerate (c)omponent "ruta"`

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-entrada',
  templateUrl: './entrada.component.html',
  styleUrls: ['./entrada.component.css']
})
export class EntradaComponent implements OnInit {

  mensaje: string = 'Soy un mensaje';
  valor1: number = 666;
  valor2: number = 777;
  valor3: number = 888;
  valor4: number = 999;
  contador: number = 0;

  constructor() { }

  ngOnInit(): void {
  }

  modificar(e) {
    let dato = e.target.value;
    this.valor3 = dato;
  }
}
