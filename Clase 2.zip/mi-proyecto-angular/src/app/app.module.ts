import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'

import { AppComponent } from './app.component';
import { EntradaComponent } from './componentes/entrada/entrada.component';
import { AtributosComponent } from './componentes/atributos/atributos.component';
import { EstructuraComponent } from './componentes/estructura/estructura.component';
import { FormulariosComponent } from './componentes/formularios/formularios.component';

@NgModule({
  declarations: [
    AppComponent,
    EntradaComponent,
    AtributosComponent,
    EstructuraComponent,
    FormulariosComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
