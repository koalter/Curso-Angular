import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http'; 

import { AppComponent } from './app.component';
import { EntradaComponent } from './componentes/entrada/entrada.component';
import { AtributosComponent } from './componentes/atributos/atributos.component';
import { EstructuraComponent } from './componentes/estructura/estructura.component';
import { FormulariosComponent } from './componentes/formularios/formularios.component';

import { ResaltarDirective } from './directivas/resaltar.directive';

import { ClientesComponent } from './componentes/clientes/clientes.component';
import { ClientesService, ClientesServiceUseClass, ClientesServiceUseExisting, functionClientesServiceUseFactory } from './servicios/clientes.service';
import { UsuariosComponent } from './componentes/usuarios/usuarios.component';

@NgModule({
  declarations: [
    AppComponent,
    EntradaComponent,
    AtributosComponent,
    EstructuraComponent,
    FormulariosComponent,
    ResaltarDirective,
    ClientesComponent,
    UsuariosComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  // providers: [ClientesService],
  providers: [
    /* Original */
    // { 
    //   provide: ClientesService,
    //   useClass: ClientesService
    // }
    /* USECLASS */
    // { provide: ClientesService, useClass: ClientesServiceUseClass }
    /* USEEXISTING */
    // { provide: ClientesService, useExisting: ClientesServiceUseExisting }
    /* USEFACTORY */
    // { provide: ClientesService, useFactory: functionClientesServiceUseFactory }
    /* USEVALUE */
    { provide: ClientesService, useValue: {
        clientes: [
          'Juan-useValue',
          'Ana-useValue',
          'Pedro-useValue',
          'Maria-useValue',
          'Pablo-useValue'
        ],
        getClientes() {
          return this.clientes
        },
        agregarCliente(client) {
          this.clientes.push(client)
        },
        borrarCliente() {
          this.clientes.pop()
        }
      } 
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
