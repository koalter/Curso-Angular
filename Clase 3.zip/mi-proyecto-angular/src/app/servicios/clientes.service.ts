import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

/* ---------------- */
/*     ORIGINAL     */
/* ---------------- */
export class ClientesService {
// export class ClientesServiceUseClass {

  private clientes: string[] = [
    'Juan-useClass',
    'Ana-useClass',
    'Pedro-useClass',
    'Maria-useClass'
  ];

  constructor() { }

  getClientes() {
    return this.clientes;
  }

  agregarCliente(client) {
    this.clientes.push(client);
  }

  borrarCliente() {
    this.clientes.pop();
  }
}
