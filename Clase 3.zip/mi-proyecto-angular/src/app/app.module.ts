import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'

import { AppComponent } from './app.component';
import { EntradaComponent } from './componentes/entrada/entrada.component';
import { AtributosComponent } from './componentes/atributos/atributos.component';
import { EstructuraComponent } from './componentes/estructura/estructura.component';
import { FormulariosComponent } from './componentes/formularios/formularios.component';

import { ResaltarDirective } from './directivas/resaltar.directive';

import { ClientesComponent } from './componentes/clientes/clientes.component';
import { ClientesService } from './servicios/clientes.service';

@NgModule({
  declarations: [
    AppComponent,
    EntradaComponent,
    AtributosComponent,
    EstructuraComponent,
    FormulariosComponent,
    ResaltarDirective,
    ClientesComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule
  ],
  // providers: [ClientesService],
  providers: [
    { 
      provide: ClientesService,
      useClass: ClientesService
      /* useExisting - useFactory - useValue */
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
